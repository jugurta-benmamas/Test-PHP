<!DOCTYPE html>
<html>
<head>
	<title>LIKELY</title>
	<meta charset="utf-8">
</head>
<body>

	<p>Bonjour <?php echo htmlspecialchars($_POST ['pseudo']); ?> !</p>
	<p>Votre email : <?php echo htmlspecialchars($_POST ['email']); ?></p>
	<p>Votre numéro de téléphone : <?php echo htmlspecialchars($_POST ['tel']); ?></p>
	<p>Votre date de naissance : <?php echo htmlspecialchars($_POST ['age']); ?></p>
	<p><?php echo 'Votre sexe : ' . $_POST['sexe'] . '.';?></p>

</body>
</html>