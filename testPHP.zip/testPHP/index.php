<?php
session_start();

?>
<!DOCTYPE html>
<html>
<head>
	<title>LIKELY</title>
	<meta charset="utf-8"/>

</head>
<body>
	<form method="POST" action="donnée.php">

		<fieldset>
			<legend>Vos coordonées</legend>
		
		<p>
			<label for="pseudo">Votre pseudo</label>
			<input type="text" name="pseudo" id="pseudo" placeholder="Pseudo" autofocus required />

		</p>

		<p>
			
			<label for="password">Mot de passe</label>
			<input type="password" name="password" id="password" minlength="6" required>

		</p>

		<p>
			<label for="email">Votre email</label>
			<input type="email" name="email" id="email" required>

		</p>

		<p>
			<label for="tel">Votre numéro de téléphone</label>
			<input type="tel" name="tel" id="tel" minlength="10" maxlength="10" required>
		</p>

		<p>
			<label for="age">Date de naissance</label>
			<input type="Date" name="age" id="age" required>

		</p>

		<p>
			Veuillez saisir votre sexe :<br>
			<input type="radio" name="sexe" value="homme" id="homme"> <label for="homme">Homme</label><br>
			<input type="radio" name="sexe" value="femme" id="femme"> <label for="femme">Femme</label><br>
			<input type="radio" name="sexe" value="autre" id="autre"> <label for="autre">Autre</label>

		</p>

		<input type="submit" value="Enoyer">
		</fieldset>
	</form>
</body>
</html>