<?php

phpinfo();